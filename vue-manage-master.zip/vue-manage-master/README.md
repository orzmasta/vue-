# 基于vue+element-ui的后台管理系统

#### 介绍
基于vue+element-ui的后台管理系统
进行了项目架构的分析
进行了项目模块的搭建
使用了脚手架的相关配置
组件化的思想，组件的一个创建
Vue-rooter路由的初始化
Vuex在项目中实现我们组件之间的一个通信
#### 软件架构
软件架构说明
vue elemtnt-ui vuex router mock

#### 安装教程

1.  npm i
2.  npm run serve


