export default {
    baseUrl:{
        dev:"/api/",//开发环境的地址
        pro:""//产品测试环境
    }
}