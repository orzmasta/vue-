<template>
<div>这里是page2</div>
</template>

<script>
export default {
  name: "pageTwo"
}
</script>

<style scoped>

</style>