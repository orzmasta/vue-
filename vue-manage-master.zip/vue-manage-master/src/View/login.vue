<template>
<div class="login">
  <el-form :model="loginData" :rules="rules" ref="loginData" label-width="100px" status-icon>
    <el-form-item label="用户名" prop="username">
      <el-input type="input" v-model="loginData.username" placeholder="请输入用户名"></el-input>
    </el-form-item>
    <el-form-item label="密码" prop="password">
      <el-input type="password" v-model="loginData.password" placeholder="请输入密码"></el-input>
    </el-form-item>
    <el-form-item class="button">
      <el-button type="primary" size="mini" @click="submit">登录</el-button>
    </el-form-item>
  </el-form>
</div>
</template>

<script>
import Mock from 'mockjs'
import {getMenu} from '../../api/data'
export default {
  data() {
    return {
      loginData: {
        password:'',
        username:''
      },
      rules: {
        username: [
          {
            required: true,
            message: "用户名不能为空",
            trigger: "blur",
          },
          {
            min: 3,
            max: 10,
            message: "长度在3到10个字符",
            trigger: "blur",
          },
        ],
        password: [
          {
            required: true,
            message: "密码不能为空",
            trigger: "blur",
          },
        ],
      },
    };
  },
  methods:{
      submit(){
          getMenu(this.loginData).then(({data:response})=>{
            console.log(response)
            if(response.code===20000){
                this.$store.commit('removeMenu')//一开始就要清除缓存的路由
                this.$store.commit('setMenu',response.data.menu)//将路由添加到cookie中
                this.$store.commit('setToken',response.data.token)//设置cookie
                this.$store.commit('getMenu',this.$router)
                this.$router.push('/home')
            }else{
              this.$message.warning(response.data.message)
              this.$router.push('/login')
            }
          })
          // const token = Mock.Random.guid()
          // this.$store.commit("setToken",token)
          // this.$router.push({path:'/home'})
      }
  }
};
</script>


<style lang="less" scoped>
.login{
    width:100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    background-image: url("../assets/images/login.jpg");
    .el-form{
        padding-top:40px;
        padding-right: 40px;
        border:2px solid rgb(64, 221, 226) ;
        border-radius:8px ;
        box-shadow:10px 10px 2px #888888;
        .button{
        display: flex;
        justify-content: center;
        padding-right:60px ;
    }
    }
}
</style>