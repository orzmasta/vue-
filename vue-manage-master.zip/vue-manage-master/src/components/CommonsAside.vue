<template>
  <el-menu
      default-active="1-4-1"
      class="el-menu-vertical-demo"
      @open="handleOpen"
      @close="handleClose"
      :collapse="isCollapse"
      background-color="#696969"
      active-text-color="#7FFFD4"
  >
    <h3>{{ isCollapse ? "后台" : "通用后台管理系统" }}</h3>
    <el-menu-item @click="clickMenu(item)"
                  v-for="item in noChildren"
                  :index="item.path"
                  :key="item.label"
    >
      <i :class="'el-icon-' + item.icon"></i>
      <span slot="title">{{ item.label }}</span>
    </el-menu-item>


    <el-submenu v-for="items in hasChildren" :key="items.label" :index="items.path">
      <template slot="title">
        <i :class="'el-icon-' + items.icon"></i>
        <span slot="title">{{ items.label }}</span>
      </template>

      <el-menu-item-group v-for="item in items.children" :key="item.label">
        <el-menu-item  @click="clickMenu(item)">{{ item.label }}</el-menu-item>
      </el-menu-item-group>
    </el-submenu>
  </el-menu>
</template>
<style lang='less' scoped>
//注意要引用less依赖
.el-menu-vertical-demo:not(.el-menu--collapse) {
  width: 200px;
  min-height: 400px;
}

.el-menu {
  height: 100%;
  border: none;

  h3 {
    color: aliceblue;
    text-align: center;
    line-height: 48px;
  }
}
</style>

<script>
export default {
  data() {
    return {
      // isCollapse: false, //表示侧边栏是否收起（true，为收起，false，为不收起）
      menu: [
        // {
        //   path: "/home",
        //   name: "home",
        //   label: "首页",
        //   icon: "s-home",
        //   url: "Home/home",
        // },
        // {
        //   path: "/mall",
        //   name: "mall",
        //   label: "商品管理",
        //   icon: "video-play",
        //   url: "MallManage/MallManage",
        // },
        // {
        //   path: "/user",
        //   name: "user",
        //   label: "用户管理",
        //   icon: "user",
        //   url: "UserManage/userManage",
        // },
        // {
        //   label: "其他",
        //   icon: "location",
        //   children: [
        //     {
        //       path: "/page1",
        //       name: "page1",
        //       label: "页面1",
        //       icon: "setting",
        //       url: "Other/pageOne",
        //     },
        //     {
        //       path: "/page2",
        //       name: "page2",
        //       label: "页面2",
        //       icon: "setting",
        //       url: "Other/pageTwo",
        //     },
        //   ],
        // },
      ],
    };

  },
  methods: {
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath);
    },
    clickMenu(item) {
      this.$router.push({
        path: item.path
      })
      this.$store.commit("tagsMenu",item)
    },

  },
  computed: {
    noChildren() {
      return this.asyncMenu.filter((item) => !item.children);
      //返回过滤器符合条件的menu，
      //过滤器就是用来筛选符合条件的一种工具
      //过滤器中的参数是menu中的参数
    },
    hasChildren() {
      return this.asyncMenu.filter((item) => item.children);
    },
    isCollapse() {
      return this.$store.state.tab.isCollapse;
    },
    asyncMenu(){
      return this.$store.state.tab.menu
    }
  },
};
</script>