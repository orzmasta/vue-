<template>
  <el-form ref="form" :model="form" label-width="200px" :inline="true">
    <el-form-item v-for="item in formLabel" :key="item.label" :label="item.label">

      <el-input
          v-if="item.type==='input'"
          :palceholder="`请输入`+item.label"
          v-model="form[item.model]">
      </el-input>

      <el-select
          v-if="item.type==='select'"
          v-model="form[item.model]"
          placeholder="请选择">
        <el-option
            v-for="item in item.opts"
            :label="item.label"
            :value="item.value"
            :key="item.value"></el-option>
      </el-select>

        <el-date-picker
            v-if="item.type==='date'"
            type="date"
            placeholder="选择日期"
            :label="item.label"
            v-model="form[item.model]"
            value-format="yyyy-MM-dd"
        ></el-date-picker>

      <el-switch v-if="item.type==='switch'" v-model="form[item.model]"></el-switch>
    </el-form-item>
    <!-- 定义一个插槽，如果前面的条件都不满足，可以通过插槽加入我们需要的组件 -->
    <el-form-item><slot></slot></el-form-item>
    
  </el-form>
</template>

<script>
export default {
  name: "CommonsFrom",
  props: {
    formLabel: Array,
    form: Object,
  },
}
</script>

<style scoped>

</style>