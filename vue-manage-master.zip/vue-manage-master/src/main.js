import Vue from 'vue'
import App from './App.vue'

//全局引用element-ui
import ElementUI from 'element-ui';
//element-ui样式文件
import 'element-ui/lib/theme-chalk/index.css';
import router from './router'
import store from './store'
import http from 'axios'
import "../api/mock.js"
router.beforeEach((to, from, next) => {
  store.commit("getToken")
  const token = store.state.user.token
  if (!token && to.path !== '/login') {
    next({ path: '/login' })
  }
  else if (token && to.path === '/login') {
    next({ path: '/home' })
  }
  else {
    next()
  }
})


Vue.use(ElementUI);
Vue.use(router);
Vue.prototype.$axios = http;//由于axios是插件，所以用这个方法经行全局引用

new Vue({
  store,
  router,
  created() {
    store.commit('getMenu', router)//在网页创建之前就加载路由，防止刷新白屏
  },
  render: h => h(App),
}).$mount('#app')
