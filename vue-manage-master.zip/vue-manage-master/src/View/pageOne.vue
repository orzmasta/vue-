<template>
<div>这里是page1</div>
</template>

<script>
export default {
  name: "pageOne"
}
</script>

<style scoped>

</style>