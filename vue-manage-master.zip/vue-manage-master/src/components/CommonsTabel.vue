<template>
  <div>
    <el-table :data="TableData" style="width: 100%">
      <el-table-column
        show-overflow-tooltip
        v-for="item in TableLabel"
        :key="item.label"
        :label="item.label"
      >
        <template slot-scope="scope">
          <span style="margin-left: 10xp">{{ scope.row[item.prop] }} </span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
        <el-button size="mini" type="danger" @click="handledelete(scope.row)">删除</el-button>
        </template>
        
      </el-table-column>
    </el-table>

    <el-pagination
    layout="prev,pager,next"  
     :total="pageConfig.total"
    :current-page.sync="pageConfig.page"
    @current-change = "change"
    ></el-pagination>
  </div>
</template>

<script>
export default {
  props: {
    TableData: Array,
    TableLabel: Array,
    pageConfig: Object,
  },
  methods: {
    handleEdit(rowsasdasd) {//这里的数据是从上面传过来的scope.row

      this.$emit("edit",rowsasdasd)
    },
    handledelete(row) {

      this.$emit("del",row)
    },
    change(page) {
      console.log("切换页面的page",page)//点击的页面数,官网上说是会返回当前页数，就也就是换页面后的页数
      this.$emit("change",page)
    },
  },
};
</script>

<style lang="less" scoped>

// @media only screen and (max-width:1920px) and (min-width:1366px){
//   .el-table-column{
//     width: 220;
//   }
// }响应式布局

.el-pagination {
  display: flex;
  justify-content: flex-end;
}
</style>