<template>
  <header>
    <div class="l-content">
      <el-button
        @click="HeaderButton"
        icon="el-icon-menu"
        size="mini"
      ></el-button>

      <el-breadcrumb separator="/">
        <el-breadcrumb-item v-for="tag in tags " :to="{ path: tag.path }" :key="tag.path">{{tag.label}}</el-breadcrumb-item>
      </el-breadcrumb>

    </div>
    <div class="r-content">
      <el-dropdown trigger="click">
        <span>
          <img :src="userImag" />
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>个人中心</el-dropdown-item>
          <el-dropdown-item @click.native="loginOut">退出登录</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
  </header>
</template>

<script>
import {mapState} from 'vuex'
export default {
  data() {
    return {
      userImag: require("../assets/images/kexuan.png"),
    };
  },
  
  computed:{
    ...mapState({
      tags:state => state.tab.tagsList
    }),
    
    loginOut(){
      this.$store.commit('removeToken')//移除cookie
      this.$store.commit("removeMenu")//移除侧边栏
      this.$router.push("/login")
    }

  },
  methods: {
    HeaderButton() {
      this.$store.commit("CollapseMenu");
    },
  },


};
</script>

<style lang="less" scoped>
header {
  display: flex;
  height: 100%;
  justify-content: space-between;
  align-items: center;
}
.l-content {
  display: flex;
  align-content: center;
  //与justify-content相反的对齐方式
  //justify是水平方向的对齐,align是垂直方向对齐
  .el-button {
    height: 40px;
    width: 40px;
    margin-top: 3px;
    margin-right: 20px;
  }
  a {
    margin-top: 12px;
    text-decoration: none;
  }
}
.r-content {
  img {
    width: 40px;
    height: 40px;
    border-radius: 50%;
  }
}
.el-breadcrumb{
  display: flex;
  align-items: center;
  font-size: 15px;
}
</style>


