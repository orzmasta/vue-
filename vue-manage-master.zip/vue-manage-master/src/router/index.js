import Vue from 'vue';
import VueRouter from 'vue-router';


import user from '../View/user.vue';//全局引用
import Main from '../View/Main.vue';

Vue.use(VueRouter);

const routes = [
    {
        path: '/',
        name: 'Main',
        component: Main,
        redirect:'/home',
        children: [
            // {
            //     path: '/mall',
            //     component: () => import('../View/mall.vue')//隐式引用
            // },
            // {
            //     path: '/user',
            //     component: user
            // },
            // {
            //     path: '/home',
            //     component: () => import('../View/home/index.vue')
            // },
            // {
            //     path: '/page1',
            //     component: () => import('../View/pageOne.vue')//隐式引用
            // },
            // {
            //     path: '/page2',
            //     component: () => import('../View/pageTwo')//隐式引用
            // },
        ]
    },
    {
        path:"/login",
        name:'login',
        component:()=>import('../View/login.vue')

    }
]
export default new VueRouter({
    mode: 'history',
    routes
})