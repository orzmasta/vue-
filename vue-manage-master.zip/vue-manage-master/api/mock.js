import Mock from 'mockjs'
import homeData from './MockServeData/home.js' 
import UserData from './MockServeData/user.js'
import login from './MockServeData/permission.js'
Mock.mock('/home/getData',homeData.getStatisticalData)
Mock.mock('/user/edit','post',UserData.updateUser)
Mock.mock('/user/add','post',UserData.createUser)
Mock.mock(/user\/getUserList/,'get',UserData.getUserList)
Mock.mock(/user\/del/,'get',UserData.deleteUser)
Mock.mock(/permission\/login/,'post',login.getMenu)
