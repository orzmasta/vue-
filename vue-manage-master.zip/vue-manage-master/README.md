# 基于vue+element-ui的后台管理系统

#### 介绍
基于vue+element-ui的后台管理系统,简单的项目，建议学完vue的同学可以看一下，你会学到很多东西的

#### 软件架构
软件架构说明
vue elemtnt-ui vuex router mock

#### 安装教程

1.  npm i
2.  npm run serve


