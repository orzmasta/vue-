<template>
  <div class="homeBox">
    <!-- style可以设置类型风格 -->
    <el-container>
      <el-aside width="auto">
        <commons-aside></commons-aside>
      </el-aside>
      <el-container>
        <el-header><commons-header></commons-header></el-header>
        <Tag/>
        <el-main>
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>
<script>
import CommonsAside from "../components/CommonsAside.vue";
import CommonsHeader from "../components/CommonsHeader.vue"
import Tag from "../components/Tag.vue"
export default {
  components: { 
    CommonsAside ,
    CommonsHeader,
    Tag
  },
};
</script>



<style lang="less" scoped>
.el-header {
  background-color:black;
}
.homeBox,
.el-container {
  padding: 0px; //填充顶部
  margin: 0px;
  height: 100%;
}
</style>
