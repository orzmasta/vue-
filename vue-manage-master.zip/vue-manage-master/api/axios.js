import axios from "axios"
import config from "../config"

const baseUrl = process.env.NODE_ENV === "development"? config.baseUrl.dev:config.baseUrl.pro; //判断当前环境是开发还是测试

//创建一个HttpRequest实例，里面封装axios的相关配置，以及过滤器
class HttpRequest{
    constructor(baseUrl){//构造函数，将环境地址传给HttpRequest
        this.baseUrl= baseUrl
    }
    getinsideConfig(){//编写axios的相关配置
        const config = {
            baseUrl : this.baseUrl,
            Headers:{}
        }
    }
    interceptors(instance){
        instance.interceptors.request.use(//配置请求拦截
            function(request){

                return request
            },
            function(error){
 
                return Promise.reject(error)
            }
        )
        instance.interceptors.response.use(//配置响应拦截
            function(response){

                return response
            },
            function(error){

                return Promise.reject(error)
            }
        )
    }
    
    request(options){
        const instance = axios.create();//实例化axios
        options = {...this.getinsideConfig(),...options}//封装传入的配置和该工具类的配置
        this.interceptors(instance);
        return instance(options);
    }


}
export default new HttpRequest(baseUrl)
