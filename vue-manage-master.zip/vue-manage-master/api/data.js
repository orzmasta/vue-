import axios from './axios'

export const getHomeData = () => {

    return axios.request({
        url: '/home/getData',
        method: 'get'
    })
    
}
export const getUserList = (param)=>{
    return axios.request({
        url:'/user/getUserList',
        method:'get',
        params:param //请求的参数
    })
}

export const getMenu = (params)=>{
    return axios.request({
        url:'/permission/login/',
        method:'post',
        data:params
    })
}