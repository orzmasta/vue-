<template>
    <h1>mall页面</h1>
</template>
<script>
export default{
    
}
</script>
