<template>
  <div id="app">
  <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "App",
};
</script>

<style>
html,body{
  margin: 0;/*margin :为外边框距*/
  padding: 0;/*padding :为内边框距*/
}
#app {
  position: absolute;/*absolute 绝对定位 */
  left: 0;
  top: 0;
  height: 100%;
  width: 100%;
}
</style>
