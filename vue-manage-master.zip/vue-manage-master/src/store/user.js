import cookie from 'js-cookie'
export default{
    state(){
        token:''
    },
    mutations:{
        setToken(state,val){
            state.token = val
            cookie.set("token",val)
        },
        removeToken(state){
            state.token=''
            cookie.remove("token")
        },
        getToken(state){
            state.token = state.token || cookie.get("token")
            //当结果为真时，返回第一个为真的值
            //当结果为假时，返回第二个为假的值
        }
    }
}