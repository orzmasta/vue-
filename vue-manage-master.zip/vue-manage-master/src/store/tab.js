import Cookie from 'js-cookie'
export default{
    state(){
        return{
            isCollapse:false,
            tagsList:[{
                path: "/home",
                name: "home",
                label: "首页",
                icon: "s-home",
            }],
            menu:[]//动态添加路由
        }
    },
    mutations:{
        CollapseMenu(state){
            state.isCollapse=!state.isCollapse
        },

        tagsMenu(state,val){
            if(val.name!=='home'){
                const result = state.tagsList.findIndex(item=>item.name===val.name)//如果tagsList中没有点击侧边栏的信息就添加
                if(result===-1){
                    state.tagsList.push(val)
                }
            }
        },

        closeTags(state,val){//删除标签
           const result = state.tagsList.findIndex(item=>item.path===val.path)
            state.tagsList.splice(result,1)
        },

        setMenu(state,val){//将路由设置到cookie中，
            state.menu = val
            Cookie.set('menu',JSON.stringify(val))
        },
        removeMenu(state){
            state.menu = []
            Cookie.remove('menu')
        },
        getMenu(state,router){
            if(!Cookie.get('menu')){
                return
            }
            const menu = JSON.parse(Cookie.get('menu'))//获取储存在cookie中的menu,  为什么要parse？ 从Cookie中取出的时候，要从字符串转换成json格式：
            state.menu = menu
            const menuArray = []
            menu.forEach(item => {
                if(item.children){//如果元素中有children
                    item.children = item.children.map(item=>{//.map()返回函数处理后的新数组
                        item.component = ()=>import(`../View/${item.url}`)//添加跳转组件
                        return item
                    })
                    menuArray.push(...item.children)//将children数组解构出来
                }else{
                    item.component = ()=>import(`../View/${item.url}`)
                    menuArray.push(item)
                }
            });
            //动态路由添加
            menuArray.forEach(item=>{
                router.addRoute("Main",item)
            })
            
            
        }
    }
}